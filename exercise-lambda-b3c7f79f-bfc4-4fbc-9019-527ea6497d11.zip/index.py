import boto3
ssm_client = boto3.client("ssm")
s3 = boto3.resource('s3')
def my_handler(event, context):
 name = "UserName"
 parameter = ssm_client.get_parameter(Name=name)
 name=parameter["Parameter"]["Value"]
 print(name)
 s3.Object('myawsbucket-for-test-1', 'newfile.txt').put(Body=name)
 return name